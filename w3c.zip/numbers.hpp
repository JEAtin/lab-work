class Numbers {
    public:
        printValues();
};