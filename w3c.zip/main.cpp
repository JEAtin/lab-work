#include "numbers.hpp"

int main() {
  Numbers n;
  n.printValues();
}