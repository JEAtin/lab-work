#include "numbers.hpp"
#include <iostream>
using namespace std;

void Numbers::printValues() {
    for (int i = 0; i < 10; ++i) cout << i << "/n";
}