#include "child_boid.hpp"

ChildBoid::ChildBoid(): Boid()
{}

ChildBoid::ChildBoid(ofVec3f &pos, ofVec3f &vel): Boid(pos, vel)
{}

void ChildBoid::draw()
{
   ofSetColor(0, 255, 0);
   ofCircle(position.x, position.y, 10);
}