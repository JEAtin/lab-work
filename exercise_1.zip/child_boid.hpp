#define _CHILD_BOID
#include "boid.hpp"

class ChildBoid : Boid
{    
// all the methods and variables after the
// public keyword can only be used by anyone
public:    
    ChildBoid();
    ChildBoid(ofVec3f &pos, ofVec3f &vel);
    
    ~ChildBoid();
    
    void draw() override;
};

#endif